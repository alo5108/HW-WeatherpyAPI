

```python
import json as json
import datetime
import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt
import openweathermapy.core as owm
from citipy import citipy
```


```python
lat = []
lon =[]
for x in range(50):
    lat.append(random.uniform(90, -90))
    lon.append(random.uniform(-180, 180))

```


```python
cities = []
for i in range(50):
    cities.append(citipy.nearest_city(lat[i], lon[i]))

```


```python
api_key = "5a36ca4a2a1cf794acb87b23d945ef66"
```


```python
settings = {"units": "imperial", "appid": api_key}

temp =[]
lat =[]
lon = []
clouds = []
speed= []
temp = []
humidity = []
cl = []
new_city=[]
for city in cities:
        
    try:
        name=city.city_name
        citydata = owm.get_current(name, **settings)
        cl.append(citydata)
        new_city.append(name)
        temp.append(citydata["main"]["temp_max"])
        humidity.append(citydata["main"]["humidity"])
        speed.append(citydata["wind"]["speed"])
        clouds.append(citydata["clouds"]["all"])
        lat.append(citydata["coord"]["lat"])
        lon.append(citydata["coord"]["lon"])
    
    except:
        print("Error with city data. Skipping")         

#Print the json (pretty printed)
print(json.dumps(cl, indent=4, sort_keys=True))
```

    Error with city data. Skipping
    Error with city data. Skipping
    Error with city data. Skipping
    Error with city data. Skipping
    Error with city data. Skipping
    Error with city data. Skipping
    Error with city data. Skipping
    Error with city data. Skipping
    Error with city data. Skipping
    Error with city data. Skipping
    [
        {
            "base": "stations",
            "clouds": {
                "all": 0
            },
            "cod": 200,
            "coord": {
                "lat": 23.43,
                "lon": 72.66
            },
            "dt": 1522717200,
            "id": 1263623,
            "main": {
                "humidity": 33,
                "pressure": 1009,
                "temp": 77,
                "temp_max": 77,
                "temp_min": 77
            },
            "name": "Mansa",
            "sys": {
                "country": "IN",
                "id": 7758,
                "message": 0.1643,
                "sunrise": 1522717198,
                "sunset": 1522761942,
                "type": 1
            },
            "visibility": 3000,
            "weather": [
                {
                    "description": "smoke",
                    "icon": "50d",
                    "id": 711,
                    "main": "Smoke"
                }
            ],
            "wind": {
                "deg": 330,
                "speed": 3.36
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 40
            },
            "cod": 200,
            "coord": {
                "lat": 45.45,
                "lon": 41.98
            },
            "dt": 1522715400,
            "id": 565289,
            "main": {
                "humidity": 81,
                "pressure": 1011,
                "temp": 42.8,
                "temp_max": 42.8,
                "temp_min": 42.8
            },
            "name": "Donskoye",
            "sys": {
                "country": "RU",
                "id": 7300,
                "message": 0.0034,
                "sunrise": 1522723747,
                "sunset": 1522770147,
                "type": 1
            },
            "visibility": 10000,
            "weather": [
                {
                    "description": "scattered clouds",
                    "icon": "03n",
                    "id": 802,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 310,
                "gust": 15,
                "speed": 22.37
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 36
            },
            "cod": 200,
            "coord": {
                "lat": -4.25,
                "lon": -43.02
            },
            "dt": 1522718430,
            "id": 3401992,
            "main": {
                "grnd_level": 1012.76,
                "humidity": 99,
                "pressure": 1012.76,
                "sea_level": 1023.62,
                "temp": 73.31,
                "temp_max": 73.31,
                "temp_min": 73.31
            },
            "name": "Coelho Neto",
            "rain": {
                "3h": 5.71
            },
            "sys": {
                "country": "BR",
                "message": 0.1666,
                "sunrise": 1522745616,
                "sunset": 1522789015
            },
            "weather": [
                {
                    "description": "moderate rain",
                    "icon": "10n",
                    "id": 501,
                    "main": "Rain"
                }
            ],
            "wind": {
                "deg": 21.001,
                "speed": 1.59
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 20
            },
            "cod": 200,
            "coord": {
                "lat": 78.22,
                "lon": 15.63
            },
            "dt": 1522716600,
            "id": 2729907,
            "main": {
                "humidity": 60,
                "pressure": 1029,
                "temp": 10.4,
                "temp_max": 10.4,
                "temp_min": 10.4
            },
            "name": "Longyearbyen",
            "sys": {
                "country": "NO",
                "id": 5326,
                "message": 0.0038,
                "sunrise": 1522724224,
                "sunset": 1522782617,
                "type": 1
            },
            "visibility": 10000,
            "weather": [
                {
                    "description": "few clouds",
                    "icon": "02n",
                    "id": 801,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 120,
                "speed": 18.34
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 1
            },
            "cod": 200,
            "coord": {
                "lat": 45.36,
                "lon": -73.48
            },
            "dt": 1522717200,
            "id": 6138908,
            "main": {
                "humidity": 51,
                "pressure": 1019,
                "temp": 32.81,
                "temp_max": 35.6,
                "temp_min": 28.4
            },
            "name": "Saint-Philippe",
            "sys": {
                "country": "CA",
                "id": 3851,
                "message": 0.0076,
                "sunrise": 1522751426,
                "sunset": 1522797877,
                "type": 1
            },
            "visibility": 14484,
            "weather": [
                {
                    "description": "clear sky",
                    "icon": "01n",
                    "id": 800,
                    "main": "Clear"
                }
            ],
            "wind": {
                "deg": 260,
                "speed": 6.93
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 0
            },
            "cod": 200,
            "coord": {
                "lat": 68.75,
                "lon": 161.3
            },
            "dt": 1522718432,
            "id": 2126199,
            "main": {
                "grnd_level": 1037.48,
                "humidity": 76,
                "pressure": 1037.48,
                "sea_level": 1045.66,
                "temp": 31.95,
                "temp_max": 31.95,
                "temp_min": 31.95
            },
            "name": "Cherskiy",
            "sys": {
                "country": "RU",
                "message": 0.1664,
                "sunrise": 1522692916,
                "sunset": 1522743811
            },
            "weather": [
                {
                    "description": "clear sky",
                    "icon": "01d",
                    "id": 800,
                    "main": "Clear"
                }
            ],
            "wind": {
                "deg": 136.001,
                "speed": 7.29
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 75
            },
            "cod": 200,
            "coord": {
                "lat": -42.88,
                "lon": 147.33
            },
            "dt": 1522717200,
            "id": 2163355,
            "main": {
                "humidity": 40,
                "pressure": 1015,
                "temp": 69.8,
                "temp_max": 69.8,
                "temp_min": 69.8
            },
            "name": "Hobart",
            "sys": {
                "country": "AU",
                "id": 8195,
                "message": 0.004,
                "sunrise": 1522700929,
                "sunset": 1522742315,
                "type": 1
            },
            "visibility": 10000,
            "weather": [
                {
                    "description": "broken clouds",
                    "icon": "04d",
                    "id": 803,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 300,
                "speed": 17.22
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 32
            },
            "cod": 200,
            "coord": {
                "lat": -23.12,
                "lon": -134.97
            },
            "dt": 1522718424,
            "id": 4030556,
            "main": {
                "grnd_level": 1027.1,
                "humidity": 100,
                "pressure": 1027.1,
                "sea_level": 1027.14,
                "temp": 78.35,
                "temp_max": 78.35,
                "temp_min": 78.35
            },
            "name": "Rikitea",
            "sys": {
                "country": "PF",
                "message": 0.0043,
                "sunrise": 1522768129,
                "sunset": 1522810613
            },
            "weather": [
                {
                    "description": "scattered clouds",
                    "icon": "03n",
                    "id": 802,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 10.001,
                "speed": 4.94
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 64
            },
            "cod": 200,
            "coord": {
                "lat": -10.62,
                "lon": 150.67
            },
            "dt": 1522718425,
            "id": 2132606,
            "main": {
                "grnd_level": 1017.45,
                "humidity": 100,
                "pressure": 1017.45,
                "sea_level": 1020.58,
                "temp": 82.76,
                "temp_max": 82.76,
                "temp_min": 82.76
            },
            "name": "Samarai",
            "rain": {
                "3h": 1.28
            },
            "sys": {
                "country": "PG",
                "message": 0.0049,
                "sunrise": 1522699274,
                "sunset": 1522742399
            },
            "weather": [
                {
                    "description": "light rain",
                    "icon": "10d",
                    "id": 500,
                    "main": "Rain"
                }
            ],
            "wind": {
                "deg": 14.501,
                "speed": 6.73
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 5
            },
            "cod": 200,
            "coord": {
                "lat": 23.99,
                "lon": -104.67
            },
            "dt": 1522716120,
            "id": 4011743,
            "main": {
                "humidity": 8,
                "pressure": 1016,
                "temp": 78.8,
                "temp_max": 78.8,
                "temp_min": 78.8
            },
            "name": "Constitucion",
            "sys": {
                "country": "MX",
                "id": 3983,
                "message": 0.1637,
                "sunrise": 1522759713,
                "sunset": 1522804529,
                "type": 1
            },
            "visibility": 22530,
            "weather": [
                {
                    "description": "clear sky",
                    "icon": "02n",
                    "id": 800,
                    "main": "Clear"
                }
            ],
            "wind": {
                "deg": 240,
                "speed": 14.99
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 92
            },
            "cod": 200,
            "coord": {
                "lat": -22.12,
                "lon": 14.28
            },
            "dt": 1522718434,
            "id": 3356832,
            "main": {
                "grnd_level": 1010.08,
                "humidity": 90,
                "pressure": 1010.08,
                "sea_level": 1023.33,
                "temp": 69.44,
                "temp_max": 69.44,
                "temp_min": 69.44
            },
            "name": "Henties Bay",
            "sys": {
                "country": "NA",
                "message": 0.1641,
                "sunrise": 1522732275,
                "sunset": 1522774842
            },
            "weather": [
                {
                    "description": "overcast clouds",
                    "icon": "04n",
                    "id": 804,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 86.501,
                "speed": 4.94
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 56
            },
            "cod": 200,
            "coord": {
                "lat": 71.98,
                "lon": 102.47
            },
            "dt": 1522718436,
            "id": 2022572,
            "main": {
                "grnd_level": 1023.86,
                "humidity": 81,
                "pressure": 1023.86,
                "sea_level": 1028.92,
                "temp": -8.37,
                "temp_max": -8.37,
                "temp_min": -8.37
            },
            "name": "Khatanga",
            "sys": {
                "country": "RU",
                "message": 0.1644,
                "sunrise": 1522706236,
                "sunset": 1522758761
            },
            "weather": [
                {
                    "description": "broken clouds",
                    "icon": "04d",
                    "id": 803,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 207.001,
                "speed": 7.52
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 56
            },
            "cod": 200,
            "coord": {
                "lat": -20.63,
                "lon": -46
            },
            "dt": 1522718428,
            "id": 3453439,
            "main": {
                "grnd_level": 924.32,
                "humidity": 93,
                "pressure": 924.32,
                "sea_level": 1023.98,
                "temp": 66.38,
                "temp_max": 66.38,
                "temp_min": 66.38
            },
            "name": "Ponta do Sol",
            "rain": {
                "3h": 2.205
            },
            "sys": {
                "country": "BR",
                "message": 0.003,
                "sunrise": 1522746709,
                "sunset": 1522789338
            },
            "weather": [
                {
                    "description": "light rain",
                    "icon": "10n",
                    "id": 500,
                    "main": "Rain"
                }
            ],
            "wind": {
                "deg": 256.001,
                "speed": 2.93
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 36
            },
            "cod": 200,
            "coord": {
                "lat": -33.59,
                "lon": 26.89
            },
            "dt": 1522718428,
            "id": 964432,
            "main": {
                "grnd_level": 1017.94,
                "humidity": 90,
                "pressure": 1017.94,
                "sea_level": 1026.78,
                "temp": 71.06,
                "temp_max": 71.06,
                "temp_min": 71.06
            },
            "name": "Port Alfred",
            "sys": {
                "country": "ZA",
                "message": 0.0037,
                "sunrise": 1522729553,
                "sunset": 1522771502
            },
            "weather": [
                {
                    "description": "scattered clouds",
                    "icon": "03n",
                    "id": 802,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 289.001,
                "speed": 8.75
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 36
            },
            "cod": 200,
            "coord": {
                "lat": -34.42,
                "lon": 19.24
            },
            "dt": 1522718429,
            "id": 3366880,
            "main": {
                "grnd_level": 989.33,
                "humidity": 98,
                "pressure": 989.33,
                "sea_level": 1028.64,
                "temp": 61.79,
                "temp_max": 61.79,
                "temp_min": 61.79
            },
            "name": "Hermanus",
            "rain": {
                "3h": 0.26
            },
            "sys": {
                "country": "ZA",
                "message": 0.0037,
                "sunrise": 1522731414,
                "sunset": 1522773311
            },
            "weather": [
                {
                    "description": "light rain",
                    "icon": "10n",
                    "id": 500,
                    "main": "Rain"
                }
            ],
            "wind": {
                "deg": 105.501,
                "speed": 4.72
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 90
            },
            "cod": 200,
            "coord": {
                "lat": 19.71,
                "lon": -155.08
            },
            "dt": 1522716960,
            "id": 5855927,
            "main": {
                "humidity": 69,
                "pressure": 1011,
                "temp": 69.93,
                "temp_max": 78.8,
                "temp_min": 62.6
            },
            "name": "Hilo",
            "sys": {
                "country": "US",
                "id": 818,
                "message": 0.0034,
                "sunrise": 1522771924,
                "sunset": 1522816506,
                "type": 1
            },
            "visibility": 16093,
            "weather": [
                {
                    "description": "overcast clouds",
                    "icon": "04n",
                    "id": 804,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 350,
                "speed": 9.17
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 75
            },
            "cod": 200,
            "coord": {
                "lat": 42.65,
                "lon": -73.75
            },
            "dt": 1522716840,
            "id": 5106834,
            "main": {
                "humidity": 38,
                "pressure": 1020,
                "temp": 35.1,
                "temp_max": 39.2,
                "temp_min": 30.2
            },
            "name": "Albany",
            "sys": {
                "country": "US",
                "id": 2088,
                "message": 0.0041,
                "sunrise": 1522751623,
                "sunset": 1522797805,
                "type": 1
            },
            "visibility": 16093,
            "weather": [
                {
                    "description": "broken clouds",
                    "icon": "04n",
                    "id": 803,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 250,
                "speed": 3.36
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 90
            },
            "cod": 200,
            "coord": {
                "lat": 39.95,
                "lon": -94.76
            },
            "dt": 1522715040,
            "id": 4407665,
            "main": {
                "humidity": 92,
                "pressure": 1006,
                "temp": 32,
                "temp_max": 32,
                "temp_min": 32
            },
            "name": "Kodiak",
            "sys": {
                "country": "US",
                "id": 1664,
                "message": 0.0041,
                "sunrise": 1522756780,
                "sunset": 1522802726,
                "type": 1
            },
            "visibility": 4023,
            "weather": [
                {
                    "description": "mist",
                    "icon": "50n",
                    "id": 701,
                    "main": "Mist"
                }
            ],
            "wind": {
                "deg": 110,
                "speed": 8.05
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 75
            },
            "cod": 200,
            "coord": {
                "lat": 69.44,
                "lon": -133.03
            },
            "dt": 1522717200,
            "id": 6170031,
            "main": {
                "humidity": 84,
                "pressure": 1036,
                "temp": -1.45,
                "temp_max": -0.41,
                "temp_min": -2.21
            },
            "name": "Tuktoyaktuk",
            "sys": {
                "country": "CA",
                "id": 3555,
                "message": 0.1665,
                "sunrise": 1522763191,
                "sunset": 1522814795,
                "type": 1
            },
            "visibility": 24140,
            "weather": [
                {
                    "description": "broken clouds",
                    "icon": "04n",
                    "id": 803,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 280,
                "speed": 5.82
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 24
            },
            "cod": 200,
            "coord": {
                "lat": -23.58,
                "lon": 149.07
            },
            "dt": 1522718440,
            "id": 2175403,
            "main": {
                "grnd_level": 1003.76,
                "humidity": 60,
                "pressure": 1003.76,
                "sea_level": 1026.49,
                "temp": 79.11,
                "temp_max": 79.11,
                "temp_min": 79.11
            },
            "name": "Bluff",
            "sys": {
                "country": "AU",
                "message": 0.1659,
                "sunrise": 1522699953,
                "sunset": 1522742477
            },
            "weather": [
                {
                    "description": "few clouds",
                    "icon": "02d",
                    "id": 801,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 121.001,
                "speed": 17.02
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 56
            },
            "cod": 200,
            "coord": {
                "lat": -30.97,
                "lon": 22.13
            },
            "dt": 1522718432,
            "id": 1014034,
            "main": {
                "grnd_level": 876.25,
                "humidity": 95,
                "pressure": 876.25,
                "sea_level": 1028.24,
                "temp": 54.9,
                "temp_max": 54.9,
                "temp_min": 54.9
            },
            "name": "Carnarvon",
            "sys": {
                "country": "ZA",
                "message": 0.0121,
                "sunrise": 1522730621,
                "sunset": 1522772721
            },
            "weather": [
                {
                    "description": "broken clouds",
                    "icon": "04n",
                    "id": 803,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 29.001,
                "speed": 4.72
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 36
            },
            "cod": 200,
            "coord": {
                "lat": -46.19,
                "lon": 168.86
            },
            "dt": 1522718432,
            "id": 6201424,
            "main": {
                "grnd_level": 1006.19,
                "humidity": 66,
                "pressure": 1006.19,
                "sea_level": 1021.06,
                "temp": 59,
                "temp_max": 59,
                "temp_min": 59
            },
            "name": "Mataura",
            "sys": {
                "country": "NZ",
                "message": 0.0043,
                "sunrise": 1522695883,
                "sunset": 1522737023
            },
            "weather": [
                {
                    "description": "scattered clouds",
                    "icon": "03d",
                    "id": 802,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 294.001,
                "speed": 20.83
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 90
            },
            "cod": 200,
            "coord": {
                "lat": 53.9,
                "lon": 27.56
            },
            "dt": 1522715400,
            "id": 625144,
            "main": {
                "humidity": 74,
                "pressure": 1008,
                "temp": 33.8,
                "temp_max": 33.8,
                "temp_min": 33.8
            },
            "name": "Minsk",
            "sys": {
                "country": "BY",
                "id": 7378,
                "message": 0.1671,
                "sunrise": 1522726693,
                "sunset": 1522774141,
                "type": 1
            },
            "visibility": 10000,
            "weather": [
                {
                    "description": "overcast clouds",
                    "icon": "04n",
                    "id": 804,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 270,
                "gust": 7,
                "speed": 8.95
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 100
            },
            "cod": 200,
            "coord": {
                "lat": 29.11,
                "lon": 119.65
            },
            "dt": 1522718434,
            "id": 1805528,
            "main": {
                "grnd_level": 1001.89,
                "humidity": 100,
                "pressure": 1001.89,
                "sea_level": 1026.61,
                "temp": 64.85,
                "temp_max": 64.85,
                "temp_min": 64.85
            },
            "name": "Jinhua",
            "rain": {
                "3h": 1.805
            },
            "sys": {
                "country": "CN",
                "message": 0.0058,
                "sunrise": 1522705763,
                "sunset": 1522750833
            },
            "weather": [
                {
                    "description": "light rain",
                    "icon": "10d",
                    "id": 500,
                    "main": "Rain"
                }
            ],
            "wind": {
                "deg": 161.501,
                "speed": 3.38
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 8
            },
            "cod": 200,
            "coord": {
                "lat": 65.61,
                "lon": -37.64
            },
            "dt": 1522716600,
            "id": 3424607,
            "main": {
                "humidity": 78,
                "pressure": 1018,
                "temp": 17.6,
                "temp_max": 17.6,
                "temp_min": 17.6
            },
            "name": "Tasiilaq",
            "sys": {
                "country": "GL",
                "id": 4806,
                "message": 0.0042,
                "sunrise": 1522741072,
                "sunset": 1522791103,
                "type": 1
            },
            "weather": [
                {
                    "description": "clear sky",
                    "icon": "02n",
                    "id": 800,
                    "main": "Clear"
                }
            ],
            "wind": {
                "deg": 60,
                "speed": 3.36
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 90
            },
            "cod": 200,
            "coord": {
                "lat": 47.66,
                "lon": -52.73
            },
            "dt": 1522717200,
            "id": 6167817,
            "main": {
                "humidity": 80,
                "pressure": 1012,
                "temp": 30.2,
                "temp_max": 30.2,
                "temp_min": 30.2
            },
            "name": "Torbay",
            "sys": {
                "country": "CA",
                "id": 3467,
                "message": 0.0037,
                "sunrise": 1522746330,
                "sunset": 1522793020,
                "type": 1
            },
            "visibility": 24140,
            "weather": [
                {
                    "description": "overcast clouds",
                    "icon": "04n",
                    "id": 804,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 280,
                "speed": 13.87
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 0
            },
            "cod": 200,
            "coord": {
                "lat": -9.8,
                "lon": -139.03
            },
            "dt": 1522718435,
            "id": 4020109,
            "main": {
                "grnd_level": 1022.72,
                "humidity": 100,
                "pressure": 1022.72,
                "sea_level": 1022.8,
                "temp": 81.95,
                "temp_max": 81.95,
                "temp_min": 81.95
            },
            "name": "Atuona",
            "sys": {
                "country": "PF",
                "message": 0.0086,
                "sunrise": 1522768783,
                "sunset": 1522811919
            },
            "weather": [
                {
                    "description": "clear sky",
                    "icon": "01n",
                    "id": 800,
                    "main": "Clear"
                }
            ],
            "wind": {
                "deg": 98.001,
                "speed": 16.35
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 24
            },
            "cod": 200,
            "coord": {
                "lat": 5.56,
                "lon": 95.32
            },
            "dt": 1522718203,
            "id": 1215502,
            "main": {
                "grnd_level": 996.95,
                "humidity": 100,
                "pressure": 996.95,
                "sea_level": 1022.68,
                "temp": 73.94,
                "temp_max": 73.94,
                "temp_min": 73.94
            },
            "name": "Banda Aceh",
            "sys": {
                "country": "ID",
                "message": 0.0039,
                "sunrise": 1522712203,
                "sunset": 1522756047
            },
            "weather": [
                {
                    "description": "few clouds",
                    "icon": "02d",
                    "id": 801,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 101.001,
                "speed": 1.92
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 90
            },
            "cod": 200,
            "coord": {
                "lat": 47.66,
                "lon": -52.73
            },
            "dt": 1522717200,
            "id": 6167817,
            "main": {
                "humidity": 80,
                "pressure": 1012,
                "temp": 30.2,
                "temp_max": 30.2,
                "temp_min": 30.2
            },
            "name": "Torbay",
            "sys": {
                "country": "CA",
                "id": 3467,
                "message": 0.0037,
                "sunrise": 1522746330,
                "sunset": 1522793020,
                "type": 1
            },
            "visibility": 24140,
            "weather": [
                {
                    "description": "overcast clouds",
                    "icon": "04n",
                    "id": 804,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 280,
                "speed": 13.87
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 76
            },
            "cod": 200,
            "coord": {
                "lat": -33.02,
                "lon": 27.91
            },
            "dt": 1522718437,
            "id": 1006984,
            "main": {
                "grnd_level": 1021.35,
                "humidity": 98,
                "pressure": 1021.35,
                "sea_level": 1025.89,
                "temp": 75.15,
                "temp_max": 75.15,
                "temp_min": 75.15
            },
            "name": "East London",
            "sys": {
                "country": "ZA",
                "message": 0.005,
                "sunrise": 1522729291,
                "sunset": 1522771275
            },
            "weather": [
                {
                    "description": "broken clouds",
                    "icon": "04n",
                    "id": 803,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 252.501,
                "speed": 12.21
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 56
            },
            "cod": 200,
            "coord": {
                "lat": -30.97,
                "lon": 22.13
            },
            "dt": 1522718432,
            "id": 1014034,
            "main": {
                "grnd_level": 876.25,
                "humidity": 95,
                "pressure": 876.25,
                "sea_level": 1028.24,
                "temp": 54.9,
                "temp_max": 54.9,
                "temp_min": 54.9
            },
            "name": "Carnarvon",
            "sys": {
                "country": "ZA",
                "message": 0.0121,
                "sunrise": 1522730621,
                "sunset": 1522772721
            },
            "weather": [
                {
                    "description": "broken clouds",
                    "icon": "04n",
                    "id": 803,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 29.001,
                "speed": 4.72
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 75
            },
            "cod": 200,
            "coord": {
                "lat": 69.44,
                "lon": -133.03
            },
            "dt": 1522717200,
            "id": 6170031,
            "main": {
                "humidity": 84,
                "pressure": 1036,
                "temp": -1.45,
                "temp_max": -0.41,
                "temp_min": -2.21
            },
            "name": "Tuktoyaktuk",
            "sys": {
                "country": "CA",
                "id": 3555,
                "message": 0.1665,
                "sunrise": 1522763191,
                "sunset": 1522814795,
                "type": 1
            },
            "visibility": 24140,
            "weather": [
                {
                    "description": "broken clouds",
                    "icon": "04n",
                    "id": 803,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 280,
                "speed": 5.82
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 75
            },
            "cod": 200,
            "coord": {
                "lat": -21.21,
                "lon": -159.78
            },
            "dt": 1522713600,
            "id": 4035715,
            "main": {
                "humidity": 78,
                "pressure": 1012,
                "temp": 82.4,
                "temp_max": 82.4,
                "temp_min": 82.4
            },
            "name": "Avarua",
            "sys": {
                "country": "CK",
                "id": 8340,
                "message": 0.0034,
                "sunrise": 1522774036,
                "sunset": 1522816614,
                "type": 1
            },
            "visibility": 10000,
            "weather": [
                {
                    "description": "shower rain",
                    "icon": "09n",
                    "id": 521,
                    "main": "Rain"
                }
            ],
            "wind": {
                "deg": 30,
                "speed": 5.82
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 0
            },
            "cod": 200,
            "coord": {
                "lat": -38.31,
                "lon": -60.23
            },
            "dt": 1522718438,
            "id": 3833859,
            "main": {
                "grnd_level": 1016.16,
                "humidity": 74,
                "pressure": 1016.16,
                "sea_level": 1028.07,
                "temp": 59.45,
                "temp_max": 59.45,
                "temp_min": 59.45
            },
            "name": "Barrow",
            "sys": {
                "country": "AR",
                "message": 0.0032,
                "sunrise": 1522750621,
                "sunset": 1522792238
            },
            "weather": [
                {
                    "description": "clear sky",
                    "icon": "01n",
                    "id": 800,
                    "main": "Clear"
                }
            ],
            "wind": {
                "deg": 35.001,
                "speed": 4.72
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 32
            },
            "cod": 200,
            "coord": {
                "lat": -23.12,
                "lon": -134.97
            },
            "dt": 1522718424,
            "id": 4030556,
            "main": {
                "grnd_level": 1027.1,
                "humidity": 100,
                "pressure": 1027.1,
                "sea_level": 1027.14,
                "temp": 78.35,
                "temp_max": 78.35,
                "temp_min": 78.35
            },
            "name": "Rikitea",
            "sys": {
                "country": "PF",
                "message": 0.0043,
                "sunrise": 1522768129,
                "sunset": 1522810613
            },
            "weather": [
                {
                    "description": "scattered clouds",
                    "icon": "03n",
                    "id": 802,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 10.001,
                "speed": 4.94
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 40
            },
            "cod": 200,
            "coord": {
                "lat": 28.14,
                "lon": 69.08
            },
            "dt": 1522717200,
            "id": 1178560,
            "main": {
                "humidity": 69,
                "pressure": 1004,
                "temp": 75.2,
                "temp_max": 75.2,
                "temp_min": 75.2
            },
            "name": "Ghauspur",
            "sys": {
                "country": "PK",
                "id": 7150,
                "message": 0.1652,
                "sunrise": 1522717920,
                "sunset": 1522762944,
                "type": 1
            },
            "visibility": 2000,
            "weather": [
                {
                    "description": "haze",
                    "icon": "50n",
                    "id": 721,
                    "main": "Haze"
                }
            ],
            "wind": {
                "deg": 50,
                "speed": 4.7
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 75
            },
            "cod": 200,
            "coord": {
                "lat": 5.28,
                "lon": 115.24
            },
            "dt": 1522717200,
            "id": 1733782,
            "main": {
                "humidity": 79,
                "pressure": 1011,
                "temp": 85.21,
                "temp_max": 86,
                "temp_min": 84.2
            },
            "name": "Victoria",
            "sys": {
                "country": "BN",
                "id": 8115,
                "message": 0.0043,
                "sunrise": 1522707430,
                "sunset": 1522751260,
                "type": 1
            },
            "visibility": 10000,
            "weather": [
                {
                    "description": "broken clouds",
                    "icon": "04d",
                    "id": 803,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 70,
                "speed": 4.7
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 40
            },
            "cod": 200,
            "coord": {
                "lat": 36.66,
                "lon": 137.31
            },
            "dt": 1522713600,
            "id": 1849876,
            "main": {
                "humidity": 45,
                "pressure": 1017,
                "temp": 68,
                "temp_max": 68,
                "temp_min": 68
            },
            "name": "Tateyama",
            "sys": {
                "country": "JP",
                "id": 7571,
                "message": 0.0036,
                "sunrise": 1522701273,
                "sunset": 1522746857,
                "type": 1
            },
            "visibility": 10000,
            "weather": [
                {
                    "description": "scattered clouds",
                    "icon": "03d",
                    "id": 802,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 180,
                "speed": 9.17
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 75
            },
            "cod": 200,
            "coord": {
                "lat": 6.8,
                "lon": -58.16
            },
            "dt": 1522713600,
            "id": 3378644,
            "main": {
                "humidity": 100,
                "pressure": 1010,
                "temp": 75.2,
                "temp_max": 75.2,
                "temp_min": 75.2
            },
            "name": "Georgetown",
            "sys": {
                "country": "GY",
                "id": 4343,
                "message": 0.165,
                "sunrise": 1522748998,
                "sunset": 1522792908,
                "type": 1
            },
            "visibility": 10000,
            "weather": [
                {
                    "description": "broken clouds",
                    "icon": "04n",
                    "id": 803,
                    "main": "Clouds"
                }
            ],
            "wind": {
                "deg": 20,
                "speed": 4.7
            }
        },
        {
            "base": "stations",
            "clouds": {
                "all": 75
            },
            "cod": 200,
            "coord": {
                "lat": 64.42,
                "lon": -173.23
            },
            "dt": 1522715400,
            "id": 4031574,
            "main": {
                "humidity": 92,
                "pressure": 1037,
                "temp": 28.4,
                "temp_max": 28.4,
                "temp_min": 28.4
            },
            "name": "Provideniya",
            "sys": {
                "country": "RU",
                "id": 7239,
                "message": 0.1653,
                "sunrise": 1522773708,
                "sunset": 1522823530,
                "type": 1
            },
            "visibility": 2500,
            "weather": [
                {
                    "description": "fog",
                    "icon": "50n",
                    "id": 741,
                    "main": "Fog"
                }
            ],
            "wind": {
                "deg": 294.501,
                "speed": 5.17
            }
        }
    ]
    


```python
weath_table = pd.DataFrame({"Temperature": temp,
                           "Humidity": humidity,
                           "Wind Speed": speed,
                           "Max Temperature (F)": temp,
                           "Cloudiness": clouds,
                           "Latitudes": lat,
                           "Longitudes": lon,
                           "City": new_city
                           })
weath_table
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Cloudiness</th>
      <th>Humidity</th>
      <th>Latitudes</th>
      <th>Longitudes</th>
      <th>Max Temperature (F)</th>
      <th>Temperature</th>
      <th>Wind Speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>mansa</td>
      <td>0</td>
      <td>33</td>
      <td>23.43</td>
      <td>72.66</td>
      <td>77.00</td>
      <td>77.00</td>
      <td>3.36</td>
    </tr>
    <tr>
      <th>1</th>
      <td>donskoye</td>
      <td>40</td>
      <td>81</td>
      <td>45.45</td>
      <td>41.98</td>
      <td>42.80</td>
      <td>42.80</td>
      <td>22.37</td>
    </tr>
    <tr>
      <th>2</th>
      <td>coelho neto</td>
      <td>36</td>
      <td>99</td>
      <td>-4.25</td>
      <td>-43.02</td>
      <td>73.31</td>
      <td>73.31</td>
      <td>1.59</td>
    </tr>
    <tr>
      <th>3</th>
      <td>longyearbyen</td>
      <td>20</td>
      <td>60</td>
      <td>78.22</td>
      <td>15.63</td>
      <td>10.40</td>
      <td>10.40</td>
      <td>18.34</td>
    </tr>
    <tr>
      <th>4</th>
      <td>saint-philippe</td>
      <td>1</td>
      <td>51</td>
      <td>45.36</td>
      <td>-73.48</td>
      <td>35.60</td>
      <td>35.60</td>
      <td>6.93</td>
    </tr>
    <tr>
      <th>5</th>
      <td>cherskiy</td>
      <td>0</td>
      <td>76</td>
      <td>68.75</td>
      <td>161.30</td>
      <td>31.95</td>
      <td>31.95</td>
      <td>7.29</td>
    </tr>
    <tr>
      <th>6</th>
      <td>hobart</td>
      <td>75</td>
      <td>40</td>
      <td>-42.88</td>
      <td>147.33</td>
      <td>69.80</td>
      <td>69.80</td>
      <td>17.22</td>
    </tr>
    <tr>
      <th>7</th>
      <td>rikitea</td>
      <td>32</td>
      <td>100</td>
      <td>-23.12</td>
      <td>-134.97</td>
      <td>78.35</td>
      <td>78.35</td>
      <td>4.94</td>
    </tr>
    <tr>
      <th>8</th>
      <td>samarai</td>
      <td>64</td>
      <td>100</td>
      <td>-10.62</td>
      <td>150.67</td>
      <td>82.76</td>
      <td>82.76</td>
      <td>6.73</td>
    </tr>
    <tr>
      <th>9</th>
      <td>constitucion</td>
      <td>5</td>
      <td>8</td>
      <td>23.99</td>
      <td>-104.67</td>
      <td>78.80</td>
      <td>78.80</td>
      <td>14.99</td>
    </tr>
    <tr>
      <th>10</th>
      <td>henties bay</td>
      <td>92</td>
      <td>90</td>
      <td>-22.12</td>
      <td>14.28</td>
      <td>69.44</td>
      <td>69.44</td>
      <td>4.94</td>
    </tr>
    <tr>
      <th>11</th>
      <td>khatanga</td>
      <td>56</td>
      <td>81</td>
      <td>71.98</td>
      <td>102.47</td>
      <td>-8.37</td>
      <td>-8.37</td>
      <td>7.52</td>
    </tr>
    <tr>
      <th>12</th>
      <td>ponta do sol</td>
      <td>56</td>
      <td>93</td>
      <td>-20.63</td>
      <td>-46.00</td>
      <td>66.38</td>
      <td>66.38</td>
      <td>2.93</td>
    </tr>
    <tr>
      <th>13</th>
      <td>port alfred</td>
      <td>36</td>
      <td>90</td>
      <td>-33.59</td>
      <td>26.89</td>
      <td>71.06</td>
      <td>71.06</td>
      <td>8.75</td>
    </tr>
    <tr>
      <th>14</th>
      <td>hermanus</td>
      <td>36</td>
      <td>98</td>
      <td>-34.42</td>
      <td>19.24</td>
      <td>61.79</td>
      <td>61.79</td>
      <td>4.72</td>
    </tr>
    <tr>
      <th>15</th>
      <td>hilo</td>
      <td>90</td>
      <td>69</td>
      <td>19.71</td>
      <td>-155.08</td>
      <td>78.80</td>
      <td>78.80</td>
      <td>9.17</td>
    </tr>
    <tr>
      <th>16</th>
      <td>albany</td>
      <td>75</td>
      <td>38</td>
      <td>42.65</td>
      <td>-73.75</td>
      <td>39.20</td>
      <td>39.20</td>
      <td>3.36</td>
    </tr>
    <tr>
      <th>17</th>
      <td>kodiak</td>
      <td>90</td>
      <td>92</td>
      <td>39.95</td>
      <td>-94.76</td>
      <td>32.00</td>
      <td>32.00</td>
      <td>8.05</td>
    </tr>
    <tr>
      <th>18</th>
      <td>tuktoyaktuk</td>
      <td>75</td>
      <td>84</td>
      <td>69.44</td>
      <td>-133.03</td>
      <td>-0.41</td>
      <td>-0.41</td>
      <td>5.82</td>
    </tr>
    <tr>
      <th>19</th>
      <td>bluff</td>
      <td>24</td>
      <td>60</td>
      <td>-23.58</td>
      <td>149.07</td>
      <td>79.11</td>
      <td>79.11</td>
      <td>17.02</td>
    </tr>
    <tr>
      <th>20</th>
      <td>carnarvon</td>
      <td>56</td>
      <td>95</td>
      <td>-30.97</td>
      <td>22.13</td>
      <td>54.90</td>
      <td>54.90</td>
      <td>4.72</td>
    </tr>
    <tr>
      <th>21</th>
      <td>mataura</td>
      <td>36</td>
      <td>66</td>
      <td>-46.19</td>
      <td>168.86</td>
      <td>59.00</td>
      <td>59.00</td>
      <td>20.83</td>
    </tr>
    <tr>
      <th>22</th>
      <td>minsk</td>
      <td>90</td>
      <td>74</td>
      <td>53.90</td>
      <td>27.56</td>
      <td>33.80</td>
      <td>33.80</td>
      <td>8.95</td>
    </tr>
    <tr>
      <th>23</th>
      <td>jinhua</td>
      <td>100</td>
      <td>100</td>
      <td>29.11</td>
      <td>119.65</td>
      <td>64.85</td>
      <td>64.85</td>
      <td>3.38</td>
    </tr>
    <tr>
      <th>24</th>
      <td>tasiilaq</td>
      <td>8</td>
      <td>78</td>
      <td>65.61</td>
      <td>-37.64</td>
      <td>17.60</td>
      <td>17.60</td>
      <td>3.36</td>
    </tr>
    <tr>
      <th>25</th>
      <td>torbay</td>
      <td>90</td>
      <td>80</td>
      <td>47.66</td>
      <td>-52.73</td>
      <td>30.20</td>
      <td>30.20</td>
      <td>13.87</td>
    </tr>
    <tr>
      <th>26</th>
      <td>atuona</td>
      <td>0</td>
      <td>100</td>
      <td>-9.80</td>
      <td>-139.03</td>
      <td>81.95</td>
      <td>81.95</td>
      <td>16.35</td>
    </tr>
    <tr>
      <th>27</th>
      <td>banda aceh</td>
      <td>24</td>
      <td>100</td>
      <td>5.56</td>
      <td>95.32</td>
      <td>73.94</td>
      <td>73.94</td>
      <td>1.92</td>
    </tr>
    <tr>
      <th>28</th>
      <td>torbay</td>
      <td>90</td>
      <td>80</td>
      <td>47.66</td>
      <td>-52.73</td>
      <td>30.20</td>
      <td>30.20</td>
      <td>13.87</td>
    </tr>
    <tr>
      <th>29</th>
      <td>east london</td>
      <td>76</td>
      <td>98</td>
      <td>-33.02</td>
      <td>27.91</td>
      <td>75.15</td>
      <td>75.15</td>
      <td>12.21</td>
    </tr>
    <tr>
      <th>30</th>
      <td>carnarvon</td>
      <td>56</td>
      <td>95</td>
      <td>-30.97</td>
      <td>22.13</td>
      <td>54.90</td>
      <td>54.90</td>
      <td>4.72</td>
    </tr>
    <tr>
      <th>31</th>
      <td>tuktoyaktuk</td>
      <td>75</td>
      <td>84</td>
      <td>69.44</td>
      <td>-133.03</td>
      <td>-0.41</td>
      <td>-0.41</td>
      <td>5.82</td>
    </tr>
    <tr>
      <th>32</th>
      <td>avarua</td>
      <td>75</td>
      <td>78</td>
      <td>-21.21</td>
      <td>-159.78</td>
      <td>82.40</td>
      <td>82.40</td>
      <td>5.82</td>
    </tr>
    <tr>
      <th>33</th>
      <td>barrow</td>
      <td>0</td>
      <td>74</td>
      <td>-38.31</td>
      <td>-60.23</td>
      <td>59.45</td>
      <td>59.45</td>
      <td>4.72</td>
    </tr>
    <tr>
      <th>34</th>
      <td>rikitea</td>
      <td>32</td>
      <td>100</td>
      <td>-23.12</td>
      <td>-134.97</td>
      <td>78.35</td>
      <td>78.35</td>
      <td>4.94</td>
    </tr>
    <tr>
      <th>35</th>
      <td>ghauspur</td>
      <td>40</td>
      <td>69</td>
      <td>28.14</td>
      <td>69.08</td>
      <td>75.20</td>
      <td>75.20</td>
      <td>4.70</td>
    </tr>
    <tr>
      <th>36</th>
      <td>victoria</td>
      <td>75</td>
      <td>79</td>
      <td>5.28</td>
      <td>115.24</td>
      <td>86.00</td>
      <td>86.00</td>
      <td>4.70</td>
    </tr>
    <tr>
      <th>37</th>
      <td>tateyama</td>
      <td>40</td>
      <td>45</td>
      <td>36.66</td>
      <td>137.31</td>
      <td>68.00</td>
      <td>68.00</td>
      <td>9.17</td>
    </tr>
    <tr>
      <th>38</th>
      <td>georgetown</td>
      <td>75</td>
      <td>100</td>
      <td>6.80</td>
      <td>-58.16</td>
      <td>75.20</td>
      <td>75.20</td>
      <td>4.70</td>
    </tr>
    <tr>
      <th>39</th>
      <td>provideniya</td>
      <td>75</td>
      <td>92</td>
      <td>64.42</td>
      <td>-173.23</td>
      <td>28.40</td>
      <td>28.40</td>
      <td>5.17</td>
    </tr>
  </tbody>
</table>
</div>




```python
weath_table.plot(kind='Scatter',x='Latitudes',y='Max Temperature (F)',linewidths=1,c='darkblue',grid=True,
          legend=None,figsize=(5,5),title='Latitude vs. Max Temperature ('+datetime.datetime.today().strftime('%d-%m-%Y')+')')
plt.rcParams['axes.facecolor']='lightgrey'
plt.grid(linewidth=0.5,color='white')
plt.ylim(-2,70)
plt.xlim(-90,100)


plt.show()
```


![png](output_6_0.png)



```python
weath_table.plot(kind='Scatter',x='Latitudes',y='Cloudiness',linewidths=1,c='darkblue',grid=True,
          legend=None,figsize=(5,5),title='Latitude vs. Cloudiness ('+datetime.datetime.today().strftime('%d-%m-%Y')+')')
plt.rcParams['axes.facecolor']='lightgrey'
plt.grid(linewidth=0.5,color='white')
plt.ylim(-20,60)
plt.xlim(-90,100)


plt.show()
```


![png](output_7_0.png)



```python
weath_table.plot(kind='Scatter',x='Latitudes',y='Humidity',linewidths=1,c='darkblue',grid=True,
          legend=None,figsize=(5,5),title='Latitude vs. Humidity ('+datetime.datetime.today().strftime('%d-%m-%Y')+')')
plt.rcParams['axes.facecolor']='lightgrey'
plt.grid(linewidth=0.5,color='white')
plt.ylim(50, 120)
plt.xlim(-90,100)


plt.show()
```


![png](output_8_0.png)



```python
weath_table.to_csv("weather.csv", index=False, header=True)       
```


```python
     
```


```python
    
```


```python
     
```


```python
    
```
